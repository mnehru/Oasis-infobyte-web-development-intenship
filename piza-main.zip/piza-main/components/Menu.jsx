import React from "react";
import { SectionContainer } from "./";

const Menu = () => {
  return (
    <SectionContainer id="menu">
      <article className="h-[500px] border">menu</article>
    </SectionContainer>
  );
};

export default Menu;
