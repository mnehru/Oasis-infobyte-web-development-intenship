/**
 * the SVGs import
 */
export { default as PizaYellowLogo } from "./svgs/piza yellow logo.svg";
export { default as PizaDarkLogo } from "./svgs/piza dark logo.svg";

/**
 * the images import
 */
export { default as Cherry } from "./images/Cherry.png";
export { default as HeroImage } from "./images/HeroImage.png";
export { default as ContactUsMan } from "./images/contact us man.png";
export { default as Pizza } from "./images/pizza.jpg";
export { default as ServicesPicOne } from "./images/services pic one.png";
export { default as ServicesPicTwo } from "./images/services pic two.png";
export { default as ServicesPicThree } from "./images/services pic three.png";
