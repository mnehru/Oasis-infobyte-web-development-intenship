export const footerLinks = [
  {
    title: "company",
    links: [
      {
        name: "Why Piza?",
        to: "",
      },
      {
        name: "Partner With Us",
        to: "",
      },
      {
        name: "FAQ",
        to: "",
      },
      {
        name: "Blog",
        to: "",
      },
    ],
  },
  {
    title: "support",
    links: [
      {
        name: "Account",
        to: "",
      },
      {
        name: "Support Center",
        to: "",
      },
      {
        name: "Feedback",
        to: "",
      },
      {
        name: "Contact Us",
        to: "",
      },
      {
        name: "Accessibility",
        to: "",
      },
    ],
  },
];
